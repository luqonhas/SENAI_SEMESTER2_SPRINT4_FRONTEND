function NotFound() {
    return (
      <div className="App">
        <header className="App-header">
          <h1> 404 - Not Found</h1>
        </header>
      </div>
    );
  }

export default NotFound;